import { Injectable } from '@nestjs/common';
import { chromium } from 'playwright/test';

@Injectable()
export class AppService {
  getHello(): string {
    return 'Hello World!';
  }

  async getHTML(url: string): Promise<string> {
    const browser = await chromium.launch({ headless: true });
    const page = await browser.newPage();

    const time = Date.now();
    await page.goto(url, { timeout: 60000, waitUntil: 'networkidle' });
    console.log({ url, cost: Date.now() - time });
    // 等待页面加载完成
    // await page.waitForLoadState('load', {
    //   timeout: 10000,
    // });
    // await page.waitForTimeout(5000);

    return await page.innerHTML('html');
  }

  async getContent(url: string, xpath: string): Promise<string[]> {
    const browser = await chromium.launch({ headless: true });
    const page = await browser.newPage();

    await page.goto(url, { timeout: 60000 });

    const texts = await page.locator(xpath).allInnerTexts();
    return texts;

    // 截断去重
    // return Array.from(
    //   new Set(texts.map((txt) => txt.replace(/^\s+/, '').replace(/\s+$/, ''))),
    // );
  }
}
