function deepEqual(obj1, obj2) {
  if (obj1 === obj2) {
    return true;
  }

  if (
    typeof obj1 !== "object" ||
    obj1 === null ||
    typeof obj2 !== "object" ||
    obj2 === null
  ) {
    return false;
  }

  const keys1 = Object.keys(obj1);
  const keys2 = Object.keys(obj2);

  if (keys1.length !== keys2.length) {
    return false;
  }

  for (let key of keys1) {
    if (!keys2.includes(key) || !deepEqual(obj1[key], obj2[key])) {
      return false;
    }
  }

  return true;
}

function getElementByXPath(xpath) {
  return document.evaluate(
    xpath,
    document,
    null,
    XPathResult.FIRST_ORDERED_NODE_TYPE,
    null
  ).singleNodeValue;
}

function getElementByCssSelector(selector) {
  return document.querySelector(selector);
}

function toPrecision(num, precision = 6) {
  return Number(num.toFixed(precision));
}

function computeLevenshteinDistance(a, b) {
  const matrix = [];
  const aLen = a.length;
  const bLen = b.length;

  if (!aLen) {
    return bLen;
  }

  if (!bLen) {
    return aLen;
  }

  // 初始化矩阵
  for (let i = 0; i <= bLen; i++) {
    matrix[i] = [i];
  }

  for (let j = 0; j <= aLen; j++) {
    matrix[0][j] = j;
  }

  for (let i = 1; i <= bLen; i++) {
    for (let j = 1; j <= aLen; j++) {
      if (b.charAt(i - 1) === a.charAt(j - 1)) {
        matrix[i][j] = matrix[i - 1][j - 1];
      } else {
        const min = Math.min(
          matrix[i - 1][j - 1],
          matrix[i][j - 1],
          matrix[i - 1][j]
        );
        matrix[i][j] = min + 1;
      }
    }
  }

  return matrix[bLen][aLen];
}

function swapStringByLength(a, b) {
  if (a.length > b.length) {
    return {
      min: b,
      max: a,
    };
  }

  return {
    min: a,
    max: b,
  };
}

function stripString(str) {
  return (str || "").replace(/[^a-zA-Z0-9]/g, "");
}

function isString(value) {
  return typeof value === "string";
}

function isNil(value) {
  return value === null || value === undefined;
}

function isArray(value) {
  return Array.isArray(value);
}

function isPlainObject(value) {
  return Object.prototype.toString.call(value) === "[object Object]";
}

function isNumber(value) {
  return typeof value === "number";
}

function isEmpty(value) {
  if (isNil(value)) {
    return true;
  }

  if (isString(value) && !value.length) {
    return true;
  }

  if (isArray(value) && !value.length) {
    return true;
  }

  if (isPlainObject(value) && !Object.keys(value).length) {
    return true;
  }

  if (isNumber(value) && value === 0) {
    return true;
  }

  return false;
}

function swapArrayByLength(a, b) {
  if (a.length > b.length) {
    return {
      min: b,
      max: a,
    };
  }

  return {
    min: a,
    max: b,
  };
}

function stringSimilarity(a, b) {
  const newA = stripString(a);
  const newB = stripString(b);
  if (isEmpty(newA) || isEmpty(newB)) {
    return 0;
  }

  if (newA === newB) {
    return 1;
  }

  const maxLen = Math.max(newA.length, newB.length);
  const { min, max } = swapStringByLength(newA, newB);
  const distance = computeLevenshteinDistance(max, min);
  const score = (maxLen - distance) / maxLen;
  return toPrecision(score);
}

function xpathSimilarity(a, b) {
  if (isEmpty(a) || isEmpty(b)) {
    return 0;
  }

  const aParts = a.split("/");
  const bParts = b.split("/");
  const { min, max } = swapArrayByLength(aParts, bParts);

  max.pop();
  if (max.join("/") === min.join("/")) {
    return 1;
  }

  return stringSimilarity(a, b);
}

function getXPath(element) {
  const idx = (sib, name) =>
    sib
      ? idx(sib.previousElementSibling, name || sib.localName) +
        (sib.localName == name)
      : 1;

  const segs = (elm) =>
    !elm || elm.nodeType !== 1
      ? [""]
      : [
          ...segs(elm.parentNode),
          elm instanceof HTMLElement
            ? `${elm.localName}[${idx(elm)}]`
            : `*[local-name() = '${elm.localName}'][${idx(elm)}]`,
        ];

  return segs(element).join("/");
}

function getElementFontInfo(element) {
  const fontInfoKeys = ["color", "fontSize", "fontWeight", "fontFamily"];
  const computedStyle = window.getComputedStyle(element);
  const fontInfo = {};

  fontInfoKeys.forEach((key) => {
    fontInfo[key] = computedStyle[key];
  });
  return fontInfo;
}

function getElementBySelector(selector) {
  const isXpath = selector.startsWith("/");
  return isXpath
    ? getElementByXPath(selector)
    : getElementByCssSelector(selector);
}

function getElementProperty(element) {
  const xpath = getXPath(element);
  const fontInfo = getElementFontInfo(element);
  const classList = element.className.split(" ").map((item) => item.trim());
  const tagName = element.tagName;

  return {
    xpath,
    fontInfo,
    classList,
    tagName,
  };
}

function getSimiElements(property) {
  // 通过 tag 和 class 获取满足条件的元素集合
  const selector =
    property.classList.length > 0
      ? property.tagName
      : `${property.tagName}.${property.classList.join(".")}`;

  const elements = [...document.querySelectorAll(selector)]
    .filter((element) => {
      // 筛选出XPath相似度满足阈值的元素
      const xpath = getXPath(element);
      const simi = xpathSimilarity(property.xpath, xpath);
      return simi >= 0.95;
    })
    // .filter((element) => {
    //   // 筛选出文本一样相同的元素
    //   const fontInfo = getElementFontInfo(element);
    //   return deepEqual(property.fontInfo, fontInfo);
    // });

  return elements;
}

property = getElementProperty(temp1);
getSimiElements(property);
