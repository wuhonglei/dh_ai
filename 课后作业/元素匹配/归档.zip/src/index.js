// class XPathFinder {
//   constructor() {
//     this.list = [];
//   }
//   add(xpath) {
//     let isFound = false;
//     const removedIndexXPath = xpath.replaceAll(/\[(\d+|\*)\]/g, '');
//     const xPathMatcher = xpath.match(/\[(\d+|\*)\]/g);
//     if (xPathMatcher) {
//       for (let i = 0; i < this.list.length; i++) {
//         const { blurXPath, xpaths } = this.list[i];
//         if (blurXPath.replaceAll(/\[(\d+|\*)\]/g, '') === removedIndexXPath) {
//           isFound = true;
//           if (xpaths.includes(xpath)) {
//             break;
//           }
//           xpaths.push(xpath);
//           let counter = -1;
//           this.list[i].blurXPath = blurXPath.replaceAll(
//             /\[(\d+|\*)\]/g,
//             (substring) => {
//               counter++;
//               if (substring === '[*]' || substring === xPathMatcher[counter]) {
//                 return substring;
//               }
//               return '[*]';
//             },
//           );
//           break;
//         }
//       }
//     }
//     if (!isFound) {
//       this.list.push({ blurXPath: xpath, xpaths: [xpath] });
//     }
//   }
//   remove(xpath) {
//     for (let i = 0; i < this.list.length; i++) {
//       const { xpaths } = this.list[i];
//       if (xpaths.includes(xpath)) {
//         // 1.删掉数据
//         xpaths.splice(xpaths.indexOf(xpath), 1);
//         if (!xpaths.length) {
//           this.list.splice(i, 1);
//           break;
//         }
//         // 2.重新生成blurXpath
//         let blurXPath = xpaths[0];
//         for (let j = 1; j < xpaths.length; j++) {
//           const xPathMatcher = xpath[j].match(/\[(\d+|\*)\]/g);
//           let counter = -1;
//           blurXPath = blurXPath.replaceAll(/\[(\d+|\*)\]/g, (substring) => {
//             counter++;
//             if (substring === '[*]' || substring === xPathMatcher[counter]) {
//               return substring;
//             }
//             return '[*]';
//           });
//         }
//         this.list[i].blurXPath = blurXPath;
//         break;
//       }
//     }
//   }
// }
function deepEqual(obj1, obj2) {
  if (obj1 === obj2) {
    return true;
  }

  if (
    typeof obj1 !== 'object' ||
    obj1 === null ||
    typeof obj2 !== 'object' ||
    obj2 === null
  ) {
    return false;
  }

  const keys1 = Object.keys(obj1);
  const keys2 = Object.keys(obj2);

  if (keys1.length !== keys2.length) {
    return false;
  }

  for (let key of keys1) {
    if (!keys2.includes(key) || !deepEqual(obj1[key], obj2[key])) {
      return false;
    }
  }

  return true;
}
class XPathDealer {
  constructor(windowDom, documentDom) {
    this.data = [];
    this.window = windowDom;
    this.document = documentDom;
  }
  getElementsByXPath(xpath) {
    const result = this.document.evaluate(
      xpath,
      this.document,
      null,
      XPathResult.ORDERED_NODE_SNAPSHOT_TYPE,
      null,
    );
    const eles = [];
    for (var i = 0; i < result.snapshotLength; i++) {
      eles.push(result.snapshotItem(i));
    }
    return eles;
  }

  computeXPath() {
    const xpathProperties = [];
    for (let i = 0; i < this.data.length; i++) {
      xpathProperties.push(
        ...this.mergeByXPathProperties(
          this.data[i].candidateEles.map((node) => this.getXPathProperty(node)),
        ),
      );
    }
    return this.mergeByXPathProperties(xpathProperties).map((data) =>
      data.map((item) => `${item.localName}[${item.index}]`).join('/'),
    );
  }

  mergeByXPathProperties(datas) {
    if (!datas?.length) {
      return [];
    }

    function getOnlyDiffPos(dataA, dataB) {
      if (!dataA || !dataB || dataA.length !== dataB.length) {
        return -1;
      }
      let pos = -1;
      for (let i = 0; i < dataA.length; i++) {
        if (dataA[i].localName !== dataB[i].localName) {
          return -1;
        }
        if (dataA[i].index !== dataB[i].index) {
          if (pos === -1) {
            pos = i;
          } else {
            return -1;
          }
        }
      }
      return pos;
    }
    function getSubXPath(a, end) {
      let paths = [];
      for (let i = 0; i < end && i < a.length; i++) {
        paths.push(`${a[i].localName}[${a[i].index}]`);
      }
      end < a.length && paths.push(a[end].localName);
      return paths.join('/');
    }

    let canMerge = false;
    do {
      canMerge = false;
      for (let index = 0; index < datas.length - 1; index++) {
        const current = datas[index];
        // 检查是否可以跟后面的元素做合并(相似且连续)
        const diffPos = getOnlyDiffPos(current, datas[index + 1]);
        if (
          diffPos === -1 ||
          !(current[diffPos].index >= 1) ||
          current[diffPos].index + 1 !== datas[index + 1][diffPos].index
        ) {
          continue;
        }
        canMerge = true;
        const guessTotal = this.getElementsByXPath(
          getSubXPath(current, diffPos),
        ).length;
        const guessLen = guessTotal - current[diffPos].index;
        const guessFinalIndex = index + guessLen;
        // 推测可转成'*' 或者position() > x
        if (
          guessTotal > 1 &&
          datas[guessFinalIndex]?.[diffPos]?.index === guessTotal &&
          getOnlyDiffPos(current, datas[guessFinalIndex]) === diffPos
        ) {
          datas.splice(index + 1, guessLen);
          current[diffPos].index =
            current[diffPos].index === 1
              ? '*'
              : `position() >= ${current[diffPos].index}`;
          continue;
        }
        let nextIndex = current[diffPos].index;
        do {
          nextIndex++;
          datas.splice(index + 1, 1);
        } while (
          datas[index + 1]?.[diffPos]?.index === nextIndex + 1 &&
          getOnlyDiffPos(current, datas[index + 1]) === diffPos
        );
        current[diffPos].index =
          current[diffPos].index === 1
            ? `position() <= ${nextIndex}`
            : `position() >= ${current[diffPos].index} and position() <= ${nextIndex}`;
      }
    } while (canMerge === true);

    return datas;
  }

  computeXPath1() {
    const datas = [];
    this.data.forEach(({ selectedEles, candidateEles }) => {
      datas.push(
        ...selectedEles.map((node) => this.getXPathProperty(node)),
        ...candidateEles.map((node) => this.getXPathProperty(node)),
      );
    });

    if (!datas?.length) {
      return;
    }
    if (datas.length === 1) {
      return datas[0]
        .map((item) => `${item.localName}[${item.index}]`)
        .join('/');
    }
    function getOnlyDiffIndex(a, b) {
      if (!a || !b || a.length !== b.length) {
        return -1;
      }
      let index = -1;
      for (let i = 0; i < a.length; i++) {
        if (a[i].localName !== b[i].localName) {
          return -1;
        }
        if (a[i].index === b[i].index) {
          continue;
        }
        if (index === -1) {
          index = i;
        } else {
          return -1;
        }
      }
      return index;
    }
    function getSubXPath(a, end) {
      let paths = [];
      for (let i = 0; i < end && i < a.length; i++) {
        paths.push(`${a[i].localName}[${a[i].index}]`);
      }
      return paths.join('/');
    }
    let canMerge = false;
    do {
      canMerge = false;
      for (let index = 0; index < datas.length - 1; index++) {
        // 检查是否可以跟后面的元素做合并
        const diffIdx = getOnlyDiffIndex(datas[index], datas[index + 1]);
        if (diffIdx === -1) {
          continue;
        }
        if (datas[index][diffIdx].index >= 1) {
          const guessEles = this.getElementsByXPath(
            `${getSubXPath(datas[index], diffIdx)}/${
              datas[index][diffIdx].localName
            }`,
          );
          const guessIdx =
            index + guessEles.length - datas[index][diffIdx].index;
          if (
            guessEles.length > 1 &&
            getOnlyDiffIndex(datas[index], datas[guessIdx]) === diffIdx &&
            datas[guessIdx][diffIdx].index === guessEles.length
          ) {
            datas.splice(
              index + 1,
              guessEles.length - datas[index][diffIdx].index,
            );
            datas[index][diffIdx].index =
              datas[index][diffIdx].index === 1
                ? '*'
                : `position() > ${datas[index][diffIdx].index}`;
            canMerge = true;
          }
        }
      }
    } while (canMerge === true);

    console.log(
      datas
        .map((data) =>
          data.map((item) => `${item.localName}[${item.index}]`).join('/'),
        )
        .join('\n'),
    );
  }

  getXPathProperty(element) {
    const getIndex = (elm, name) =>
      elm
        ? getIndex(elm.previousElementSibling, name || elm.localName) +
          (elm.localName == name)
        : 1;

    const segs = (elm) =>
      !elm || elm.nodeType !== 1
        ? [undefined]
        : [
            ...segs(elm.parentNode),
            {
              localName: elm.localName,
              index: getIndex(elm),
              classList: (elm.className || '')
                .split(' ')
                .filter((item) => !item.startsWith('seo-')),
            },
          ];

    return segs(element).filter((data) => data !== undefined);
  }

  getXPath(element) {
    const idx = (sib, name) =>
      sib
        ? idx(sib.previousElementSibling, name || sib.localName) +
          (sib.localName == name)
        : 1;

    const segs = (elm) =>
      !elm || elm.nodeType !== 1
        ? ['']
        : [
            ...segs(elm.parentNode),
            `${elm.localName}[${idx(elm)}]`,
            //   elm instanceof HTMLElement
            //     ? `${elm.localName}[${idx(elm)}]`
            //     : `*[local-name() = '${elm.localName}'][${idx(elm)}]`,
          ];

    return segs(element).join('/');
  }
  getElementFontInfo(element) {
    const fontInfoKeys = ['color', 'fontSize', 'fontWeight', 'fontFamily'];
    const computedStyle = this.window.getComputedStyle(element);
    const fontInfo = {};

    fontInfoKeys.forEach((key) => {
      fontInfo[key] = computedStyle[key];
    });
    return fontInfo;
  }
  getElementProperty(element) {
    const xpath = this.getXPath(element);
    const fontInfo = this.getElementFontInfo(element);
    const classList = element.className
      .split(' ')
      .map((item) => item.trim())
      .filter((item) => !item.startsWith('seo-'));
    const tagName = element.tagName;

    return {
      xpath,
      fontInfo,
      classList,
      tagName,
    };
  }
  // 获取相似元素
  getSimiElements(selectedDom) {
    function toPrecision(num, precision = 6) {
      return Number(num.toFixed(precision));
    }

    function computeLevenshteinDistance(a, b) {
      const matrix = [];
      const aLen = a.length;
      const bLen = b.length;

      if (!aLen) {
        return bLen;
      }

      if (!bLen) {
        return aLen;
      }

      // 初始化矩阵
      for (let i = 0; i <= bLen; i++) {
        matrix[i] = [i];
      }

      for (let j = 0; j <= aLen; j++) {
        matrix[0][j] = j;
      }

      for (let i = 1; i <= bLen; i++) {
        for (let j = 1; j <= aLen; j++) {
          if (b.charAt(i - 1) === a.charAt(j - 1)) {
            matrix[i][j] = matrix[i - 1][j - 1];
          } else {
            const min = Math.min(
              matrix[i - 1][j - 1],
              matrix[i][j - 1],
              matrix[i - 1][j],
            );
            matrix[i][j] = min + 1;
          }
        }
      }

      return matrix[bLen][aLen];
    }

    function swapStringByLength(a, b) {
      if (a.length > b.length) {
        return {
          min: b,
          max: a,
        };
      }

      return {
        min: a,
        max: b,
      };
    }

    function stripString(str) {
      return (str || '').replace(/[^a-zA-Z0-9]/g, '');
    }

    function isString(value) {
      return typeof value === 'string';
    }

    function isNil(value) {
      return value === null || value === undefined;
    }

    function isArray(value) {
      return Array.isArray(value);
    }

    function isPlainObject(value) {
      return Object.prototype.toString.call(value) === '[object Object]';
    }

    function isNumber(value) {
      return typeof value === 'number';
    }

    function isEmpty(value) {
      if (isNil(value)) {
        return true;
      }

      if (isString(value) && !value.length) {
        return true;
      }

      if (isArray(value) && !value.length) {
        return true;
      }

      if (isPlainObject(value) && !Object.keys(value).length) {
        return true;
      }

      if (isNumber(value) && value === 0) {
        return true;
      }

      return false;
    }

    function swapArrayByLength(a, b) {
      if (a.length > b.length) {
        return {
          min: b,
          max: a,
        };
      }

      return {
        min: a,
        max: b,
      };
    }

    function stringSimilarity(a, b) {
      const newA = stripString(a);
      const newB = stripString(b);
      if (isEmpty(newA) || isEmpty(newB)) {
        return 0;
      }

      if (newA === newB) {
        return 1;
      }

      const maxLen = Math.max(newA.length, newB.length);
      const { min, max } = swapStringByLength(newA, newB);
      const distance = computeLevenshteinDistance(max, min);
      const score = (maxLen - distance) / maxLen;
      return toPrecision(score);
    }

    function xpathSimilarity(a, b) {
      if (isEmpty(a) || isEmpty(b)) {
        return 0;
      }

      const aParts = a.split('/');
      const bParts = b.split('/');
      const { min, max } = swapArrayByLength(aParts, bParts);

      max.pop();
      if (max.join('/') === min.join('/')) {
        return 1;
      }

      return stringSimilarity(a, b);
    }

    // 通过 tag 和 class 获取满足条件的元素集合
    const property = this.getElementProperty(selectedDom);
    const selector =
      property.classList.length === 0
        ? property.tagName
        : `${property.tagName}.${property.classList.join('.')}`;
    return [...this.document.querySelectorAll(selector)]
      .filter((element) => {
        // 筛选出XPath相似度满足阈值的元素
        const xpath = this.getXPath(element);
        const simi = xpathSimilarity(property.xpath, xpath);
        return simi >= 0.8;
      })
      .filter((element) => {
        // 筛选出文本一样相同的元素
        const fontInfo = this.getElementFontInfo(element);
        return deepEqual(property.fontInfo, fontInfo);
      });
  }
  click(selectedDom) {
    if (!selectedDom) {
      return;
    }
    const index = this.data.findIndex(({ candidateEles }) =>
      candidateEles.includes(selectedDom),
    );
    // 如果不存在，创建新的数据
    if (index === -1) {
      selectedDom.classList.add('seo-selected');
      const candidateEles = this.getSimiElements(selectedDom);
      candidateEles.forEach(
        (ele) =>
          !ele.classList.contains('seo-selected') &&
          ele.classList.add('seo-candidate'),
      );
      this.data.push({
        selectedEles: [selectedDom],
        candidateEles,
      });
      return;
    }
    const { selectedEles, candidateEles } = this.data[index];
    // 如果存在于candidate，改变样式，直接返回
    if (!selectedEles.includes(selectedDom)) {
      selectedEles.push(selectedDom);
      selectedDom.classList.remove('seo-candidate');
      selectedDom.classList.add('seo-selected');
      return;
    }
    // 如果存在于selected，删掉相关的数据和candiate
    selectedDom.classList.remove('seo-selected');
    selectedEles.splice(selectedEles.indexOf(selectedDom), 1);
    if (selectedEles.length) {
      selectedDom.classList.add('seo-candidate');
    } else {
      candidateEles.forEach((ele) => ele.classList.remove('seo-candidate'));
      this.data.splice(index, 1);
    }
  }
}

const xpathDom = document.getElementById('xpath');
const iframeDom = document.getElementById('htmlWindow');
let isHiding = false;
$('#goBtn').click(function () {
  const url = $('#url').val();
  $.get(`http://localhost:3001/getHTML?url=${url}`, function (data) {
    iframeDom.srcdoc = data
      .replace('<head>', `<head><base href="${url}" />`)
      .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
      .replace(
        '</body>',
        `
        <div id="seo-mask"></div>
        <style>
            #seo-mask {
              position: fixed;
              width: 100vw;
              height: 100%;
              top: 0;
              left: 0;
              z-index: 10000000;
            }
            .seo-hidding {
              display: none;
            }
            .seo-hover {
              z-index: 1600000;
              outline: 2px solid red!important;
              outline-offset: -2px;
              -webkit-transition: outline-width 0s !important;
              transition: outline-width 0s !important;
            }
            .seo-selected {
              z-index: 1600000;
              outline: 3px solid green!important;
              outline-offset: -3px;
              -webkit-transition: outline-width 0s !important;
              transition: outline-width 0s !important;
            }
            .seo-candidate {
              z-index: 1600000;
              outline: 3px dotted green!important;
              outline-offset: -3px;
              -webkit-transition: outline-width 0s !important;
              transition: outline-width 0s !important;
            }
        </style>
      </body>
    `,
      );
  });
});
$('#hideBtn').click(function () {
  isHiding = !isHiding;
});
$('#resetBtn').click(function () {
  const documentDom = iframeDom.contentWindow.document;
  const hidingEles = documentDom.querySelectorAll('.seo-hidding');
  for (let i = 0; i < hidingEles.length; i++) {
    hidingEles[i].classList.remove('seo-hidding');
  }
});

iframeDom.onload = function () {
  const windowDom = iframeDom.contentWindow;
  const documentDom = windowDom.document;
  const xpathDealer = new XPathDealer(windowDom, documentDom);
  let lastSelectDom = null;
  windowDom.addEventListener(
    'click',
    () => {
      if (isHiding) {
        lastSelectDom.classList.add('seo-hidding');
      } else {
        xpathDealer.click(lastSelectDom);
        console.log(xpathDealer.computeXPath());
      }
    },
    true,
  );
  windowDom.addEventListener(
    'mousemove',
    (event) => {
      const maskDom = documentDom.getElementById('seo-mask');
      const { target, clientX, clientY } = event;
      if (maskDom !== target) {
        return;
      }
      target.style.display = 'none';
      const newSelectDom = documentDom.elementFromPoint(clientX, clientY);
      target.style.display = 'block';
      if (
        /^(HTML|BODY|DOCUMENT)$/i.test(newSelectDom.tagName) === false &&
        newSelectDom !== lastSelectDom
      ) {
        lastSelectDom?.classList.remove('seo-hover');
        newSelectDom?.classList.add('seo-hover');
        lastSelectDom = newSelectDom;
      }
    },
    true,
  );
};
