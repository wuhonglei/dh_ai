package crawl

import (
	"context"
	"fmt"
	"time"

	"git.garena.com/shopee/marketing/seo/config/spexconfigcenter"
	context2 "git.garena.com/shopee/marketing/seo/util/context"
	"github.com/chromedp/cdproto/page"
	"github.com/chromedp/chromedp"
	"github.com/chromedp/chromedp/kb"
	"go.uber.org/zap"
)

var (
	chromeCtx         context.Context
	userAgent         = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
	concurrentLimitCh = make(chan struct{}, 1)
	stopChrome        context.CancelFunc
)

func init() {
	err := initChrome()
	if err != nil {
		panic(fmt.Sprintf("start chrome failed, err=%s", err.Error()))
		return
	}
}
func resetChrome() error {
	stopChrome()
	return initChrome()
}

func initChrome() error {
	options := []chromedp.ExecAllocatorOption{
		chromedp.NoFirstRun,
		chromedp.NoDefaultBrowserCheck,
		chromedp.Headless,
		chromedp.DisableGPU,
		chromedp.Flag("disable-background-networking", false),
		chromedp.Flag("blink-settings", "imageEnable=false"),
		chromedp.Flag("enable-automation", false),
		chromedp.UserAgent(userAgent),
	}
	c, _ := chromedp.NewExecAllocator(context.Background(), options...)
	chromeCtx, stopChrome = chromedp.NewContext(c)
	return chromedp.Run(chromeCtx, make([]chromedp.Action, 0, 1)...)
}

func DownloadHtml(url string, isWait bool) (string, error) {
	concurrentLimitCh <- struct{}{}
	defer func() {
		<-concurrentLimitCh
	}()
	waitSeconds := int64(10)
	configWaitSeconds := spexconfigcenter.Global().GetCrawlTaskConfig().MaxWaitSecond
	if configWaitSeconds > 0 {
		waitSeconds = configWaitSeconds
	}

	timeOutCtx, cancel := context.WithTimeout(chromeCtx, time.Duration(waitSeconds)*time.Second)
	defer cancel()

	ch := make(chan struct{})
	logCtx := context2.NewContextWithSequence(nil)
	logCtx.LogI("download start", zap.String("url", url))
	var htmlContent string
	var err error
	go func() {
		htmlContent, err = getHtml(logCtx, timeOutCtx, url, ch, isWait)
	}()
	deadlineCtx, _ := context.WithTimeout(context.Background(), time.Duration(waitSeconds+10)*time.Second)
	select {
	case <-ch:
		return htmlContent, err
	case <-deadlineCtx.Done():
		logCtx.LogI("time over")
		return "", fmt.Errorf("load page overtime, try again")
	}
}

func getHtml(logCtx context2.Context, chromeCtx context.Context, url string, ch chan struct{}, isWait bool) (string, error) {
	var htmlContent string
	var err error
	for {
		deadline, _ := chromeCtx.Deadline()
		restSecond := deadline.Unix() - time.Now().Unix()
		sleepSecond := int64(0)
		// 8 second for read html
		if restSecond-8 > 0 && isWait {
			sleepSecond = restSecond - 8
		}
		err = chromedp.Run(chromeCtx,
			navigate(logCtx, url, "networkIdle", isWait),
			chromedp.Sleep(time.Second*time.Duration(sleepSecond)),
			chromedp.OuterHTML(`document.querySelector("html")`, &htmlContent, chromedp.ByJSPath))
		if err != nil && err.Error() == "retry" {
			continue
		}
		break
	}
	if err != nil {
		if err.Error() != "context deadline exceeded" {
			resetChrome()
			logCtx.LogE("reset chrome")
		}
		logCtx.LogE("get result failed", zap.Error(err))
		err = fmt.Errorf("failed to load page, try again")
	}
	logCtx.LogI("download end")
	close(ch)
	return htmlContent, err
}

func navigate(logCtx context2.Context, url string, eventName string, isWait bool) chromedp.ActionFunc {
	if isWait {
		return func(ctx context.Context) error {
			_, _, errorText, err := page.Navigate(url).Do(ctx)
			if err != nil {
				return err
			}
			if errorText != "" {
				return fmt.Errorf("page load error %s", errorText)
			}
			return nil
		}
	}
	return navigateAndWaitFor(logCtx, url, eventName)
}

func navigateAndWaitFor(logCtx context2.Context, url string, eventName string) chromedp.ActionFunc {
	return func(ctx context.Context) error {
		frameId, loaderId, errorText, err := page.Navigate(url).Do(ctx)
		if err != nil {
			return err
		}
		if errorText != "" {
			return fmt.Errorf("page load error %s", errorText)
		}
		logCtx.LogI("begin to wait", zap.Reflect("frame", frameId), zap.Reflect("loader", loaderId))
		return waitFor(logCtx, ctx, eventName)
	}
}

// waitFor blocks until eventName is received.
// Examples of events you can wait for:
//
//	init, DOMContentLoaded, firstPaint,
//	firstContentfulPaint, firstImagePaint,
//	firstMeaningfulPaintCandidate,
//	load, networkAlmostIdle, firstMeaningfulPaint, networkIdle
//
// This is not super reliable, I've already found incidental cases where
// networkIdle was sent before load. It's probably smart to see how
// puppeteer implements this exactly.
func waitFor(logCtx context2.Context, ctx context.Context, eventName string) error {
	ch := make(chan struct{})
	retryCh := make(chan struct{})
	startTime := int64(0)
	firstInit := true
	maxWaitCtx, _ := logCtx.WithTimeout(time.Second * 6)
	cctx, cancel := context.WithCancel(ctx)
	chromedp.ListenTarget(cctx, func(ev interface{}) {
		switch e := ev.(type) {
		case *page.EventLifecycleEvent:
			logCtx.LogI("catch event", zap.String("event", e.Name))
			if e.Name == "init" {
				if firstInit {
					chromedp.Sleep(time.Second)
					chromedp.KeyEvent(kb.End)
					startTime = time.Now().Unix()
					firstInit = false
				}
			} else {
				startTime = 0
			}
			if e.Name == eventName {
				cancel()
				close(ch)
			}
		}
	})
	go func() {
		routineStartTime := time.Now().Unix()
		for {
			now := time.Now().Unix()
			if startTime != 0 && now-startTime > 3 {
				close(retryCh)
				return
			}
			// 120s must exit
			if now-routineStartTime > 120 {
				return
			}
			time.Sleep(time.Second)
		}
	}()
	select {
	case <-maxWaitCtx.Done():
		return nil
	case <-ch:
		return nil
	case <-retryCh:
		return fmt.Errorf("retry")
	case <-ctx.Done():
		return ctx.Err()
	}
}

func setTask(url string, sels []string, res *string, dur time.Duration) chromedp.Tasks {
	var actions []chromedp.Action
	actions = append(actions, chromedp.Navigate(url))
	actions = append(actions, chromedp.Sleep(time.Second))
	actions = append(actions, chromedp.KeyEvent(kb.End))
	for _, sel := range sels {
		actions = append(actions, chromedp.WaitVisible(sel))
	}
	if dur-time.Second > 0 {
		actions = append(actions, chromedp.Sleep(dur-time.Second))
	}
	actions = append(actions, chromedp.OuterHTML(`document.querySelector("html")`, res, chromedp.ByJSPath))
	return actions
}
