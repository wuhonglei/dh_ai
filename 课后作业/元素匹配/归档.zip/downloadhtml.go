package crawl

import (
	"context"
	"fmt"
	"time"

	"git.garena.com/shopee/marketing/seo/config/spexconfigcenter"
	"github.com/chromedp/cdproto/page"
	"github.com/chromedp/chromedp"
	"github.com/chromedp/chromedp/kb"
)

var (
	chromeCtx         context.Context
	userAgent         = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
	concurrentLimitCh = make(chan struct{}, 1)
)

func init() {
	options := []chromedp.ExecAllocatorOption{
		chromedp.NoFirstRun,
		chromedp.NoDefaultBrowserCheck,
		chromedp.Headless,
		chromedp.DisableGPU,
		chromedp.Flag("disable-background-networking", false),
		chromedp.Flag("blink-settings", "imageEnable=false"),
		chromedp.Flag("enable-automation", false),
		chromedp.UserAgent(userAgent),
	}
	c, _ := chromedp.NewExecAllocator(context.Background(), options...)
	chromeCtx, _ = chromedp.NewContext(c)
	err := chromedp.Run(chromeCtx, make([]chromedp.Action, 0, 1)...)
	if err != nil {
		panic(fmt.Sprintf("start chrome failed, err=%s", err.Error()))
		return
	}
}

func DownloadHtml(url string, isWait bool) (string, error) {
	concurrentLimitCh <- struct{}{}
	defer func() {
		<-concurrentLimitCh
	}()
	waitSeconds := int64(10)
	configWaitSeconds := spexconfigcenter.Global().GetCrawlTaskConfig().MaxWaitSecond
	if configWaitSeconds > 0 {
		waitSeconds = configWaitSeconds
	}

	timeOutCtx, cancel := context.WithTimeout(chromeCtx, time.Duration(waitSeconds)*time.Second)
	defer cancel()

	deadlineCtx, _ := context.WithTimeout(context.Background(), time.Duration(waitSeconds+20)*time.Second)
	ch := make(chan struct{})
	var htmlContent string
	var err error
	go func() {
		getHtmlWaitSecond := int64(0)
		if isWait {
			getHtmlWaitSecond = waitSeconds
		}
		htmlContent, err = getHtml(chromeCtx, timeOutCtx, url, ch, getHtmlWaitSecond)
	}()
	select {
	case <-ch:
		return htmlContent, err
	case <-deadlineCtx.Done():
		return "", fmt.Errorf("failed to open the browser，try again")
	}
}

func getHtml(parentCtx context.Context, childCtx context.Context, url string, ch chan struct{}, waitSeconds int64) (string, error) {
	var htmlContent string
	err := chromedp.Run(childCtx,
		navigateAndWaitFor(url, "networkIdle"),
		chromedp.Sleep(time.Second*time.Duration(waitSeconds)),
		chromedp.OuterHTML(`document.querySelector("html")`, &htmlContent, chromedp.ByJSPath))
	if err != nil && err.Error() == "context deadline exceeded" {
		err = chromedp.Run(parentCtx,
			chromedp.OuterHTML(`document.querySelector("html")`, &htmlContent, chromedp.ByJSPath), //生成最终的html文件并保存在htmlContent文件中
		)
	}
	close(ch)
	return htmlContent, err
}

func navigateAndWaitFor(url string, eventName string) chromedp.ActionFunc {
	return func(ctx context.Context) error {
		_, _, errorText, err := page.Navigate(url).Do(ctx)
		if err != nil {
			return err
		}
		if errorText != "" {
			return fmt.Errorf("page load error %s", errorText)
		}
		chromedp.Sleep(time.Second)
		chromedp.KeyEvent(kb.End)
		chromedp.Sleep(time.Second)
		return waitFor(ctx, eventName)
	}
}

// waitFor blocks until eventName is received.
// Examples of events you can wait for:
//
//	init, DOMContentLoaded, firstPaint,
//	firstContentfulPaint, firstImagePaint,
//	firstMeaningfulPaintCandidate,
//	load, networkAlmostIdle, firstMeaningfulPaint, networkIdle
//
// This is not super reliable, I've already found incidental cases where
// networkIdle was sent before load. It's probably smart to see how
// puppeteer implements this exactly.
func waitFor(ctx context.Context, eventName string) error {
	ch := make(chan struct{})
	cctx, cancel := context.WithCancel(ctx)
	chromedp.ListenTarget(cctx, func(ev interface{}) {
		switch e := ev.(type) {
		case *page.EventLifecycleEvent:
			if e.Name == eventName {
				cancel()
				close(ch)
			}
		}
	})
	select {
	case <-ch:
		return nil
	case <-ctx.Done():
		return ctx.Err()
	}
}

func setTask(url string, sels []string, res *string, dur time.Duration) chromedp.Tasks {
	var actions []chromedp.Action
	actions = append(actions, chromedp.Navigate(url))
	actions = append(actions, chromedp.Sleep(time.Second))
	actions = append(actions, chromedp.KeyEvent(kb.End))
	for _, sel := range sels {
		actions = append(actions, chromedp.WaitVisible(sel))
	}
	if dur-time.Second > 0 {
		actions = append(actions, chromedp.Sleep(dur-time.Second))
	}
	actions = append(actions, chromedp.OuterHTML(`document.querySelector("html")`, res, chromedp.ByJSPath))
	return actions
}
